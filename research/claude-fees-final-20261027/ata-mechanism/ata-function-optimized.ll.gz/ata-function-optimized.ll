define hidden { i64, ptr } @_ZN19pump_fees_candidate12instructions11fee_sharing30admit_associated_token_account17h0fc0eaa708d42eb2E(ptr noalias noundef readonly align 8 dereferenceable(48) %associated_account, ptr noalias nocapture noundef readonly align 8 dereferenceable(48) %wallet, ptr noalias noundef readonly align 1 dereferenceable(32) %mint, ptr noalias noundef readonly align 1 dereferenceable(32) %token_program, ptr noalias nocapture noundef readonly align 8 dereferenceable(48) %mint_info, ptr noalias nocapture noundef readonly align 8 dereferenceable(48) %token_program_info, i1 noundef zeroext %create_if_missing, ptr noalias nocapture noundef readonly align 8 dereferenceable(8) %payer, ptr noalias nocapture noundef readonly align 8 dereferenceable(8) %system_program) unnamed_addr #1 {
start:
  %_11.i116 = alloca [0 x i8], align 1
  %formatter.i117 = alloca [64 x i8], align 8
  %buf.i118 = alloca [24 x i8], align 8
  %formatter.i17 = alloca [64 x i8], align 8
  %buf.i18 = alloca [24 x i8], align 8
  %formatter.i = alloca [64 x i8], align 8
  %buf.i = alloca [24 x i8], align 8
  %_122 = alloca [24 x i8], align 8
  %_111 = alloca [24 x i8], align 8
  %_91 = alloca [64 x i8], align 1
  %_83 = alloca [160 x i8], align 8
  %_77 = alloca [16 x i8], align 8
  %_75 = alloca [176 x i8], align 8
  %account = alloca [176 x i8], align 8
  %_70 = alloca [24 x i8], align 8
  %_65 = alloca [64 x i8], align 1
  %_58 = alloca [24 x i8], align 8
  %_57 = alloca [160 x i8], align 8
  %_46 = alloca [288 x i8], align 8
  %_42 = alloca [24 x i8], align 8
  %_40 = alloca [32 x i8], align 1
  %_38 = alloca [32 x i8], align 1
  %instruction = alloca [80 x i8], align 8
  %_30 = alloca [24 x i8], align 8
  %_29 = alloca [160 x i8], align 8
  %_24 = alloca [64 x i8], align 1
  %_18 = alloca [24 x i8], align 8
  %_17 = alloca [160 x i8], align 8
  %_14 = alloca [32 x i8], align 1
  %_12 = alloca [32 x i8], align 1
  %expected = alloca [32 x i8], align 1
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %expected)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_12)
  %_96 = load ptr, ptr %wallet, align 8, !nonnull !2, !align !209, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_12, ptr noundef nonnull align 1 dereferenceable(32) %_96, i64 32, i1 false)
; call spl_associated_token_account_client::address::get_associated_token_address_with_program_id
  call void @_ZN35spl_associated_token_account_client7address44get_associated_token_address_with_program_id17h2fe531d7023e1d74E(ptr noalias nocapture noundef nonnull sret([32 x i8]) align 1 dereferenceable(32) %expected, ptr noalias noundef nonnull readonly align 1 dereferenceable(32) %_12, ptr noalias noundef nonnull readonly align 1 dereferenceable(32) %mint, ptr noalias noundef nonnull readonly align 1 dereferenceable(32) %token_program) #25
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_12)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_14)
  %_97 = load ptr, ptr %associated_account, align 8, !nonnull !2, !align !209, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_14, ptr noundef nonnull align 1 dereferenceable(32) %_97, i64 32, i1 false)
  %0 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_14, ptr noundef nonnull dereferenceable(32) %expected, i64 32)
  %.not = icmp eq i32 %0, 0
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_14)
  br i1 %.not, label %bb7, label %bb2

bb7:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %associated_account, i64 24
  %_101 = load ptr, ptr %1, align 8, !nonnull !2, !align !209, !noundef !2
  %2 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_101, ptr noundef nonnull dereferenceable(32) @alloc_6ca8591423d98ecbd315de1d1a6fea68, i64 32)
  %3 = icmp eq i32 %2, 0
  br i1 %3, label %bb8, label %bb23

bb2:                                              ; preds = %start
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_17)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_18)
; call anchor_lang::error::ErrorCode::name
  call void @_ZN11anchor_lang5error9ErrorCode4name17h868fe43de25476a9E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_18, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_2f475e84d260dce0bf2e60beae6b9ec7) #25
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i116)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i), !noalias !5731
  store i64 0, ptr %buf.i, align 8, !noalias !5731
  %_9.sroa.4.0.buf.sroa_idx.i = getelementptr inbounds i8, ptr %buf.i, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i, align 8, !noalias !5731
  %_9.sroa.5.0.buf.sroa_idx.i = getelementptr inbounds i8, ptr %buf.i, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i, align 8, !noalias !5731
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i), !noalias !5731
  %4 = getelementptr inbounds i8, ptr %formatter.i, i64 52
  store i32 0, ptr %4, align 4, !noalias !5731
  %5 = getelementptr inbounds i8, ptr %formatter.i, i64 48
  store i32 32, ptr %5, align 8, !noalias !5731
  %6 = getelementptr inbounds i8, ptr %formatter.i, i64 56
  store i8 3, ptr %6, align 8, !noalias !5731
  store i64 0, ptr %formatter.i, align 8, !noalias !5731
  %7 = getelementptr inbounds i8, ptr %formatter.i, i64 16
  store i64 0, ptr %7, align 8, !noalias !5731
  %8 = getelementptr inbounds i8, ptr %formatter.i, i64 32
  store ptr %buf.i, ptr %8, align 8, !noalias !5731
  %9 = getelementptr inbounds i8, ptr %formatter.i, i64 40
  store ptr @vtable.1, ptr %9, align 8, !noalias !5731
; call <anchor_lang::error::ErrorCode as core::fmt::Display>::fmt
  %10 = call noundef zeroext i1 @"_ZN68_$LT$anchor_lang..error..ErrorCode$u20$as$u20$core..fmt..Display$GT$3fmt17h57789061e8d1ec45E"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_2f475e84d260dce0bf2e60beae6b9ec7, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i) #25, !noalias !5735
  br i1 %10, label %bb3.i, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h3f8720cb5c1d2f09E.exit"

bb3.i:                                            ; preds = %bb2
; call core::result::unwrap_failed
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i116, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.2, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #26, !noalias !5735
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h3f8720cb5c1d2f09E.exit": ; preds = %bb2
  %11 = getelementptr inbounds i8, ptr %_17, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %11, ptr noundef nonnull align 8 dereferenceable(24) %buf.i, i64 24, i1 false)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i), !noalias !5731
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i), !noalias !5731
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i116)
  %12 = getelementptr inbounds i8, ptr %_17, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %12, ptr noundef nonnull align 8 dereferenceable(24) %_18, i64 24, i1 false)
  %13 = getelementptr inbounds i8, ptr %_17, i64 152
  store i32 2006, ptr %13, align 8
  store i64 0, ptr %_17, align 8
  %_20.sroa.4.0._17.sroa_idx = getelementptr inbounds i8, ptr %_17, i64 8
  store ptr @alloc_a5bc4269938b4f19311b42ee946762e5, ptr %_20.sroa.4.0._17.sroa_idx, align 8
  %_20.sroa.4.sroa.4.0._20.sroa.4.0._17.sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_17, i64 16
  store i64 54, ptr %_20.sroa.4.sroa.4.0._20.sroa.4.0._17.sroa_idx.sroa_idx, align 8
  %_20.sroa.4.sroa.5.0._20.sroa.4.0._17.sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_17, i64 24
  store i32 273, ptr %_20.sroa.4.sroa.5.0._20.sroa.4.0._17.sroa_idx.sroa_idx, align 8
  %14 = getelementptr inbounds i8, ptr %_17, i64 80
  store i8 2, ptr %14, align 8
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_18)
; call <anchor_lang::error::Error as core::convert::From<anchor_lang::error::AnchorError>>::from
  %15 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h98c0c5a28b5a1c88E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_17) #25
  %_16.0 = extractvalue { i64, ptr } %15, 0
  %_16.1 = extractvalue { i64, ptr } %15, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_17)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %_24)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_24, ptr noundef nonnull align 1 dereferenceable(32) %_97, i64 32, i1 false)
  %16 = getelementptr inbounds i8, ptr %_24, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %16, ptr noundef nonnull align 1 dereferenceable(32) %expected, i64 32, i1 false)
; call anchor_lang::error::Error::with_pubkeys
  %17 = call { i64, ptr } @_ZN11anchor_lang5error5Error12with_pubkeys17hda5126e2516455afE(i64 noundef %_16.0, ptr noundef %_16.1, ptr noalias nocapture noundef nonnull readonly align 1 dereferenceable(64) %_24) #25
  %_15.0 = extractvalue { i64, ptr } %17, 0
  %_15.1 = extractvalue { i64, ptr } %17, 1
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %_24)
  br label %bb43

bb23:                                             ; preds = %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h877e270bb2588328E.exit", %bb7
  %18 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_101, ptr noundef nonnull dereferenceable(32) %token_program, i64 32)
  %.not13 = icmp eq i32 %18, 0
  br i1 %.not13, label %bb29, label %bb24

bb8:                                              ; preds = %bb7
  br i1 %create_if_missing, label %bb13, label %bb9

bb9:                                              ; preds = %bb8
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_29)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_30)
; call anchor_lang::error::ErrorCode::name
  call void @_ZN11anchor_lang5error9ErrorCode4name17h868fe43de25476a9E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_30, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_34f98efaaefeba3e70f7cb335625c0f9) #25
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i116)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i18), !noalias !5736
  store i64 0, ptr %buf.i18, align 8, !noalias !5736
  %_9.sroa.4.0.buf.sroa_idx.i19 = getelementptr inbounds i8, ptr %buf.i18, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i19, align 8, !noalias !5736
  %_9.sroa.5.0.buf.sroa_idx.i20 = getelementptr inbounds i8, ptr %buf.i18, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i20, align 8, !noalias !5736
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i17), !noalias !5736
  %19 = getelementptr inbounds i8, ptr %formatter.i17, i64 52
  store i32 0, ptr %19, align 4, !noalias !5736
  %20 = getelementptr inbounds i8, ptr %formatter.i17, i64 48
  store i32 32, ptr %20, align 8, !noalias !5736
  %21 = getelementptr inbounds i8, ptr %formatter.i17, i64 56
  store i8 3, ptr %21, align 8, !noalias !5736
  store i64 0, ptr %formatter.i17, align 8, !noalias !5736
  %22 = getelementptr inbounds i8, ptr %formatter.i17, i64 16
  store i64 0, ptr %22, align 8, !noalias !5736
  %23 = getelementptr inbounds i8, ptr %formatter.i17, i64 32
  store ptr %buf.i18, ptr %23, align 8, !noalias !5736
  %24 = getelementptr inbounds i8, ptr %formatter.i17, i64 40
  store ptr @vtable.1, ptr %24, align 8, !noalias !5736
; call <anchor_lang::error::ErrorCode as core::fmt::Display>::fmt
  %25 = call noundef zeroext i1 @"_ZN68_$LT$anchor_lang..error..ErrorCode$u20$as$u20$core..fmt..Display$GT$3fmt17h57789061e8d1ec45E"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_34f98efaaefeba3e70f7cb335625c0f9, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i17) #25, !noalias !5740
  br i1 %25, label %bb3.i21, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h3f8720cb5c1d2f09E.exit22"

bb3.i21:                                          ; preds = %bb9
; call core::result::unwrap_failed
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i116, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.2, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #26, !noalias !5740
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h3f8720cb5c1d2f09E.exit22": ; preds = %bb9
  %26 = getelementptr inbounds i8, ptr %_29, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %26, ptr noundef nonnull align 8 dereferenceable(24) %buf.i18, i64 24, i1 false)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i17), !noalias !5736
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i18), !noalias !5736
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i116)
  %27 = getelementptr inbounds i8, ptr %_29, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %27, ptr noundef nonnull align 8 dereferenceable(24) %_30, i64 24, i1 false)
  %28 = getelementptr inbounds i8, ptr %_29, i64 152
  store i32 3012, ptr %28, align 8
  store i64 0, ptr %_29, align 8
  %_32.sroa.4.0._29.sroa_idx = getelementptr inbounds i8, ptr %_29, i64 8
  store ptr @alloc_a5bc4269938b4f19311b42ee946762e5, ptr %_32.sroa.4.0._29.sroa_idx, align 8
  %_32.sroa.4.sroa.4.0._32.sroa.4.0._29.sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_29, i64 16
  store i64 54, ptr %_32.sroa.4.sroa.4.0._32.sroa.4.0._29.sroa_idx.sroa_idx, align 8
  %_32.sroa.4.sroa.5.0._32.sroa.4.0._29.sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_29, i64 24
  store i32 278, ptr %_32.sroa.4.sroa.5.0._32.sroa.4.0._29.sroa_idx.sroa_idx, align 8
  %29 = getelementptr inbounds i8, ptr %_29, i64 80
  store i8 2, ptr %29, align 8
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_30)
; call <anchor_lang::error::Error as core::convert::From<anchor_lang::error::AnchorError>>::from
  %30 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h98c0c5a28b5a1c88E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_29) #25
  %_28.0 = extractvalue { i64, ptr } %30, 0
  %_28.1 = extractvalue { i64, ptr } %30, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_29)
  br label %bb43

bb13:                                             ; preds = %bb8
  call void @llvm.lifetime.start.p0(i64 80, ptr nonnull %instruction)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_38)
  %_105 = load ptr, ptr %payer, align 8, !nonnull !2, !align !3, !noundef !2
  %_106 = load ptr, ptr %_105, align 8, !nonnull !2, !align !209, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_38, ptr noundef nonnull align 1 dereferenceable(32) %_106, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_40)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_40, ptr noundef nonnull align 1 dereferenceable(32) %_96, i64 32, i1 false)
; call spl_associated_token_account_client::instruction::create_associated_token_account_idempotent
  call void @_ZN35spl_associated_token_account_client11instruction42create_associated_token_account_idempotent17hd227c7eff80482f5E(ptr noalias nocapture noundef nonnull sret([80 x i8]) align 8 dereferenceable(80) %instruction, ptr noalias noundef nonnull readonly align 1 dereferenceable(32) %_38, ptr noalias noundef nonnull readonly align 1 dereferenceable(32) %_40, ptr noalias noundef nonnull readonly align 1 dereferenceable(32) %mint, ptr noalias noundef nonnull readonly align 1 dereferenceable(32) %token_program) #25
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_40)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_38)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_42)
  call void @llvm.lifetime.start.p0(i64 288, ptr nonnull %_46)
  call void @llvm.experimental.noalias.scope.decl(metadata !5741)
  %_2.i = load ptr, ptr %_105, align 8, !alias.scope !5741, !noalias !5744, !nonnull !2, !align !209, !noundef !2
  %31 = getelementptr inbounds i8, ptr %_105, i64 8
  %_12.i = load ptr, ptr %31, align 8, !alias.scope !5741, !noalias !5744, !nonnull !2, !noundef !2
  %self.val.i.i = load i64, ptr %_12.i, align 8, !noalias !5746, !noundef !2
  %cond.i.i = icmp ne i64 %self.val.i.i, 0
  call void @llvm.assume(i1 %cond.i.i)
  %strong1.i.i = add i64 %self.val.i.i, 1
  store i64 %strong1.i.i, ptr %_12.i, align 8, !noalias !5746
  %_7.i.i = icmp eq i64 %strong1.i.i, 0
  br i1 %_7.i.i, label %bb4.i.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i

bb4.i.i:                                          ; preds = %bb13
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i: ; preds = %bb13
  %32 = getelementptr inbounds i8, ptr %_105, i64 16
  %_16.i = load ptr, ptr %32, align 8, !alias.scope !5741, !noalias !5744, !nonnull !2, !noundef !2
  %self.val.i1.i = load i64, ptr %_16.i, align 8, !noalias !5746, !noundef !2
  %cond.i2.i = icmp ne i64 %self.val.i1.i, 0
  call void @llvm.assume(i1 %cond.i2.i)
  %strong1.i3.i = add i64 %self.val.i1.i, 1
  store i64 %strong1.i3.i, ptr %_16.i, align 8, !noalias !5746
  %_7.i4.i = icmp eq i64 %strong1.i3.i, 0
  br i1 %_7.i4.i, label %bb4.i5.i, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit"

bb4.i5.i:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i
  %33 = getelementptr inbounds i8, ptr %_105, i64 24
  %_5.i = load ptr, ptr %33, align 8, !alias.scope !5741, !noalias !5744, !nonnull !2, !align !209, !noundef !2
  %34 = getelementptr inbounds i8, ptr %_105, i64 32
  %_6.i = load i64, ptr %34, align 8, !alias.scope !5741, !noalias !5744, !noundef !2
  %35 = getelementptr inbounds i8, ptr %_105, i64 40
  %36 = load i8, ptr %35, align 8, !range !211, !alias.scope !5741, !noalias !5744, !noundef !2
  %37 = getelementptr inbounds i8, ptr %_105, i64 41
  %38 = load i8, ptr %37, align 1, !range !211, !alias.scope !5741, !noalias !5744, !noundef !2
  %39 = getelementptr inbounds i8, ptr %_105, i64 42
  %40 = load i8, ptr %39, align 2, !range !211, !alias.scope !5741, !noalias !5744, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !5747)
  %41 = getelementptr inbounds i8, ptr %associated_account, i64 8
  %_12.i24 = load ptr, ptr %41, align 8, !alias.scope !5747, !noalias !5750, !nonnull !2, !noundef !2
  %self.val.i.i25 = load i64, ptr %_12.i24, align 8, !noalias !5752, !noundef !2
  %cond.i.i26 = icmp ne i64 %self.val.i.i25, 0
  call void @llvm.assume(i1 %cond.i.i26)
  %strong1.i.i27 = add i64 %self.val.i.i25, 1
  store i64 %strong1.i.i27, ptr %_12.i24, align 8, !noalias !5752
  %_7.i.i28 = icmp eq i64 %strong1.i.i27, 0
  br i1 %_7.i.i28, label %bb4.i.i38, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i29

bb4.i.i38:                                        ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i29: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit"
  %42 = getelementptr inbounds i8, ptr %associated_account, i64 16
  %_16.i30 = load ptr, ptr %42, align 8, !alias.scope !5747, !noalias !5750, !nonnull !2, !noundef !2
  %self.val.i1.i31 = load i64, ptr %_16.i30, align 8, !noalias !5752, !noundef !2
  %cond.i2.i32 = icmp ne i64 %self.val.i1.i31, 0
  call void @llvm.assume(i1 %cond.i2.i32)
  %strong1.i3.i33 = add i64 %self.val.i1.i31, 1
  store i64 %strong1.i3.i33, ptr %_16.i30, align 8, !noalias !5752
  %_7.i4.i34 = icmp eq i64 %strong1.i3.i33, 0
  br i1 %_7.i4.i34, label %bb4.i5.i37, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit39"

bb4.i5.i37:                                       ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i29
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit39": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i29
  %43 = getelementptr inbounds i8, ptr %associated_account, i64 32
  %_6.i36 = load i64, ptr %43, align 8, !alias.scope !5747, !noalias !5750, !noundef !2
  %44 = getelementptr inbounds i8, ptr %associated_account, i64 40
  %45 = load i8, ptr %44, align 8, !range !211, !alias.scope !5747, !noalias !5750, !noundef !2
  %46 = getelementptr inbounds i8, ptr %associated_account, i64 41
  %47 = load i8, ptr %46, align 1, !range !211, !alias.scope !5747, !noalias !5750, !noundef !2
  %48 = getelementptr inbounds i8, ptr %associated_account, i64 42
  %49 = load i8, ptr %48, align 2, !range !211, !alias.scope !5747, !noalias !5750, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !5753)
  %50 = getelementptr inbounds i8, ptr %wallet, i64 8
  %_12.i41 = load ptr, ptr %50, align 8, !alias.scope !5753, !noalias !5756, !nonnull !2, !noundef !2
  %self.val.i.i42 = load i64, ptr %_12.i41, align 8, !noalias !5758, !noundef !2
  %cond.i.i43 = icmp ne i64 %self.val.i.i42, 0
  call void @llvm.assume(i1 %cond.i.i43)
  %strong1.i.i44 = add i64 %self.val.i.i42, 1
  store i64 %strong1.i.i44, ptr %_12.i41, align 8, !noalias !5758
  %_7.i.i45 = icmp eq i64 %strong1.i.i44, 0
  br i1 %_7.i.i45, label %bb4.i.i55, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i46

bb4.i.i55:                                        ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit39"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i46: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit39"
  %51 = getelementptr inbounds i8, ptr %wallet, i64 16
  %_16.i47 = load ptr, ptr %51, align 8, !alias.scope !5753, !noalias !5756, !nonnull !2, !noundef !2
  %self.val.i1.i48 = load i64, ptr %_16.i47, align 8, !noalias !5758, !noundef !2
  %cond.i2.i49 = icmp ne i64 %self.val.i1.i48, 0
  call void @llvm.assume(i1 %cond.i2.i49)
  %strong1.i3.i50 = add i64 %self.val.i1.i48, 1
  store i64 %strong1.i3.i50, ptr %_16.i47, align 8, !noalias !5758
  %_7.i4.i51 = icmp eq i64 %strong1.i3.i50, 0
  br i1 %_7.i4.i51, label %bb4.i5.i54, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit56"

bb4.i5.i54:                                       ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i46
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit56": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i46
  %52 = getelementptr inbounds i8, ptr %wallet, i64 24
  %_5.i52 = load ptr, ptr %52, align 8, !alias.scope !5753, !noalias !5756, !nonnull !2, !align !209, !noundef !2
  %53 = getelementptr inbounds i8, ptr %wallet, i64 32
  %_6.i53 = load i64, ptr %53, align 8, !alias.scope !5753, !noalias !5756, !noundef !2
  %54 = getelementptr inbounds i8, ptr %wallet, i64 40
  %55 = load i8, ptr %54, align 8, !range !211, !alias.scope !5753, !noalias !5756, !noundef !2
  %56 = getelementptr inbounds i8, ptr %wallet, i64 41
  %57 = load i8, ptr %56, align 1, !range !211, !alias.scope !5753, !noalias !5756, !noundef !2
  %58 = getelementptr inbounds i8, ptr %wallet, i64 42
  %59 = load i8, ptr %58, align 2, !range !211, !alias.scope !5753, !noalias !5756, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !5759)
  %_2.i57 = load ptr, ptr %mint_info, align 8, !alias.scope !5759, !noalias !5762, !nonnull !2, !align !209, !noundef !2
  %60 = getelementptr inbounds i8, ptr %mint_info, i64 8
  %_12.i58 = load ptr, ptr %60, align 8, !alias.scope !5759, !noalias !5762, !nonnull !2, !noundef !2
  %self.val.i.i59 = load i64, ptr %_12.i58, align 8, !noalias !5764, !noundef !2
  %cond.i.i60 = icmp ne i64 %self.val.i.i59, 0
  call void @llvm.assume(i1 %cond.i.i60)
  %strong1.i.i61 = add i64 %self.val.i.i59, 1
  store i64 %strong1.i.i61, ptr %_12.i58, align 8, !noalias !5764
  %_7.i.i62 = icmp eq i64 %strong1.i.i61, 0
  br i1 %_7.i.i62, label %bb4.i.i72, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i63

bb4.i.i72:                                        ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit56"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i63: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit56"
  %61 = getelementptr inbounds i8, ptr %mint_info, i64 16
  %_16.i64 = load ptr, ptr %61, align 8, !alias.scope !5759, !noalias !5762, !nonnull !2, !noundef !2
  %self.val.i1.i65 = load i64, ptr %_16.i64, align 8, !noalias !5764, !noundef !2
  %cond.i2.i66 = icmp ne i64 %self.val.i1.i65, 0
  call void @llvm.assume(i1 %cond.i2.i66)
  %strong1.i3.i67 = add i64 %self.val.i1.i65, 1
  store i64 %strong1.i3.i67, ptr %_16.i64, align 8, !noalias !5764
  %_7.i4.i68 = icmp eq i64 %strong1.i3.i67, 0
  br i1 %_7.i4.i68, label %bb4.i5.i71, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit73"

bb4.i5.i71:                                       ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i63
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit73": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i63
  %62 = getelementptr inbounds i8, ptr %mint_info, i64 24
  %_5.i69 = load ptr, ptr %62, align 8, !alias.scope !5759, !noalias !5762, !nonnull !2, !align !209, !noundef !2
  %63 = getelementptr inbounds i8, ptr %mint_info, i64 32
  %_6.i70 = load i64, ptr %63, align 8, !alias.scope !5759, !noalias !5762, !noundef !2
  %64 = getelementptr inbounds i8, ptr %mint_info, i64 40
  %65 = load i8, ptr %64, align 8, !range !211, !alias.scope !5759, !noalias !5762, !noundef !2
  %66 = getelementptr inbounds i8, ptr %mint_info, i64 41
  %67 = load i8, ptr %66, align 1, !range !211, !alias.scope !5759, !noalias !5762, !noundef !2
  %68 = getelementptr inbounds i8, ptr %mint_info, i64 42
  %69 = load i8, ptr %68, align 2, !range !211, !alias.scope !5759, !noalias !5762, !noundef !2
  %_107 = load ptr, ptr %system_program, align 8, !nonnull !2, !align !3, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !5765)
  %_2.i74 = load ptr, ptr %_107, align 8, !alias.scope !5765, !noalias !5768, !nonnull !2, !align !209, !noundef !2
  %70 = getelementptr inbounds i8, ptr %_107, i64 8
  %_12.i75 = load ptr, ptr %70, align 8, !alias.scope !5765, !noalias !5768, !nonnull !2, !noundef !2
  %self.val.i.i76 = load i64, ptr %_12.i75, align 8, !noalias !5770, !noundef !2
  %cond.i.i77 = icmp ne i64 %self.val.i.i76, 0
  call void @llvm.assume(i1 %cond.i.i77)
  %strong1.i.i78 = add i64 %self.val.i.i76, 1
  store i64 %strong1.i.i78, ptr %_12.i75, align 8, !noalias !5770
  %_7.i.i79 = icmp eq i64 %strong1.i.i78, 0
  br i1 %_7.i.i79, label %bb4.i.i89, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i80

bb4.i.i89:                                        ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit73"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i80: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit73"
  %71 = getelementptr inbounds i8, ptr %_107, i64 16
  %_16.i81 = load ptr, ptr %71, align 8, !alias.scope !5765, !noalias !5768, !nonnull !2, !noundef !2
  %self.val.i1.i82 = load i64, ptr %_16.i81, align 8, !noalias !5770, !noundef !2
  %cond.i2.i83 = icmp ne i64 %self.val.i1.i82, 0
  call void @llvm.assume(i1 %cond.i2.i83)
  %strong1.i3.i84 = add i64 %self.val.i1.i82, 1
  store i64 %strong1.i3.i84, ptr %_16.i81, align 8, !noalias !5770
  %_7.i4.i85 = icmp eq i64 %strong1.i3.i84, 0
  br i1 %_7.i4.i85, label %bb4.i5.i88, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit90"

bb4.i5.i88:                                       ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i80
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit90": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i80
  %72 = getelementptr inbounds i8, ptr %_107, i64 24
  %_5.i86 = load ptr, ptr %72, align 8, !alias.scope !5765, !noalias !5768, !nonnull !2, !align !209, !noundef !2
  %73 = getelementptr inbounds i8, ptr %_107, i64 32
  %_6.i87 = load i64, ptr %73, align 8, !alias.scope !5765, !noalias !5768, !noundef !2
  %74 = getelementptr inbounds i8, ptr %_107, i64 40
  %75 = load i8, ptr %74, align 8, !range !211, !alias.scope !5765, !noalias !5768, !noundef !2
  %76 = getelementptr inbounds i8, ptr %_107, i64 41
  %77 = load i8, ptr %76, align 1, !range !211, !alias.scope !5765, !noalias !5768, !noundef !2
  %78 = getelementptr inbounds i8, ptr %_107, i64 42
  %79 = load i8, ptr %78, align 2, !range !211, !alias.scope !5765, !noalias !5768, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !5771)
  %_2.i91 = load ptr, ptr %token_program_info, align 8, !alias.scope !5771, !noalias !5774, !nonnull !2, !align !209, !noundef !2
  %80 = getelementptr inbounds i8, ptr %token_program_info, i64 8
  %_12.i92 = load ptr, ptr %80, align 8, !alias.scope !5771, !noalias !5774, !nonnull !2, !noundef !2
  %self.val.i.i93 = load i64, ptr %_12.i92, align 8, !noalias !5776, !noundef !2
  %cond.i.i94 = icmp ne i64 %self.val.i.i93, 0
  call void @llvm.assume(i1 %cond.i.i94)
  %strong1.i.i95 = add i64 %self.val.i.i93, 1
  store i64 %strong1.i.i95, ptr %_12.i92, align 8, !noalias !5776
  %_7.i.i96 = icmp eq i64 %strong1.i.i95, 0
  br i1 %_7.i.i96, label %bb4.i.i106, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i97

bb4.i.i106:                                       ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit90"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i97: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit90"
  %81 = getelementptr inbounds i8, ptr %token_program_info, i64 16
  %_16.i98 = load ptr, ptr %81, align 8, !alias.scope !5771, !noalias !5774, !nonnull !2, !noundef !2
  %self.val.i1.i99 = load i64, ptr %_16.i98, align 8, !noalias !5776, !noundef !2
  %cond.i2.i100 = icmp ne i64 %self.val.i1.i99, 0
  call void @llvm.assume(i1 %cond.i2.i100)
  %strong1.i3.i101 = add i64 %self.val.i1.i99, 1
  store i64 %strong1.i3.i101, ptr %_16.i98, align 8, !noalias !5776
  %_7.i4.i102 = icmp eq i64 %strong1.i3.i101, 0
  br i1 %_7.i4.i102, label %bb4.i5.i105, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit107"

bb4.i5.i105:                                      ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i97
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit107": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hb904a109b3c82c6eE.exit.i97
  %82 = getelementptr inbounds i8, ptr %token_program_info, i64 24
  %_5.i103 = load ptr, ptr %82, align 8, !alias.scope !5771, !noalias !5774, !nonnull !2, !align !209, !noundef !2
  %83 = getelementptr inbounds i8, ptr %token_program_info, i64 32
  %_6.i104 = load i64, ptr %83, align 8, !alias.scope !5771, !noalias !5774, !noundef !2
  %84 = getelementptr inbounds i8, ptr %token_program_info, i64 40
  %85 = load i8, ptr %84, align 8, !range !211, !alias.scope !5771, !noalias !5774, !noundef !2
  %86 = getelementptr inbounds i8, ptr %token_program_info, i64 41
  %87 = load i8, ptr %86, align 1, !range !211, !alias.scope !5771, !noalias !5774, !noundef !2
  %88 = getelementptr inbounds i8, ptr %token_program_info, i64 42
  %89 = load i8, ptr %88, align 2, !range !211, !alias.scope !5771, !noalias !5774, !noundef !2
  store ptr %_2.i, ptr %_46, align 8
  %_47.sroa.4.0._46.sroa_idx = getelementptr inbounds i8, ptr %_46, i64 8
  store ptr %_12.i, ptr %_47.sroa.4.0._46.sroa_idx, align 8
  %_47.sroa.5.0._46.sroa_idx = getelementptr inbounds i8, ptr %_46, i64 16
  store ptr %_16.i, ptr %_47.sroa.5.0._46.sroa_idx, align 8
  %_47.sroa.6.0._46.sroa_idx = getelementptr inbounds i8, ptr %_46, i64 24
  store ptr %_5.i, ptr %_47.sroa.6.0._46.sroa_idx, align 8
  %_47.sroa.7.0._46.sroa_idx = getelementptr inbounds i8, ptr %_46, i64 32
  store i64 %_6.i, ptr %_47.sroa.7.0._46.sroa_idx, align 8
  %_47.sroa.8.0._46.sroa_idx = getelementptr inbounds i8, ptr %_46, i64 40
  store i8 %36, ptr %_47.sroa.8.0._46.sroa_idx, align 8
  %_47.sroa.9.0._46.sroa_idx = getelementptr inbounds i8, ptr %_46, i64 41
  store i8 %38, ptr %_47.sroa.9.0._46.sroa_idx, align 1
  %_47.sroa.10.0._46.sroa_idx = getelementptr inbounds i8, ptr %_46, i64 42
  store i8 %40, ptr %_47.sroa.10.0._46.sroa_idx, align 2
  %90 = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 1
  store ptr %_97, ptr %90, align 8
  %_48.sroa.4.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 1, i32 1
  store ptr %_12.i24, ptr %_48.sroa.4.0..sroa_idx, align 8
  %_48.sroa.5.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 1, i32 2
  store ptr %_16.i30, ptr %_48.sroa.5.0..sroa_idx, align 8
  %_48.sroa.6.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 1, i32 3
  store ptr %_101, ptr %_48.sroa.6.0..sroa_idx, align 8
  %_48.sroa.7.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 1, i32 4
  store i64 %_6.i36, ptr %_48.sroa.7.0..sroa_idx, align 8
  %_48.sroa.8.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 1, i32 5
  store i8 %45, ptr %_48.sroa.8.0..sroa_idx, align 8
  %_48.sroa.9.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 1, i32 6
  store i8 %47, ptr %_48.sroa.9.0..sroa_idx, align 1
  %_48.sroa.10.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 1, i32 7
  store i8 %49, ptr %_48.sroa.10.0..sroa_idx, align 2
  %91 = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 2
  store ptr %_96, ptr %91, align 8
  %_49.sroa.4.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 2, i32 1
  store ptr %_12.i41, ptr %_49.sroa.4.0..sroa_idx, align 8
  %_49.sroa.5.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 2, i32 2
  store ptr %_16.i47, ptr %_49.sroa.5.0..sroa_idx, align 8
  %_49.sroa.6.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 2, i32 3
  store ptr %_5.i52, ptr %_49.sroa.6.0..sroa_idx, align 8
  %_49.sroa.7.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 2, i32 4
  store i64 %_6.i53, ptr %_49.sroa.7.0..sroa_idx, align 8
  %_49.sroa.8.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 2, i32 5
  store i8 %55, ptr %_49.sroa.8.0..sroa_idx, align 8
  %_49.sroa.9.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 2, i32 6
  store i8 %57, ptr %_49.sroa.9.0..sroa_idx, align 1
  %_49.sroa.10.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 2, i32 7
  store i8 %59, ptr %_49.sroa.10.0..sroa_idx, align 2
  %92 = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 3
  store ptr %_2.i57, ptr %92, align 8
  %_50.sroa.4.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 3, i32 1
  store ptr %_12.i58, ptr %_50.sroa.4.0..sroa_idx, align 8
  %_50.sroa.5.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 3, i32 2
  store ptr %_16.i64, ptr %_50.sroa.5.0..sroa_idx, align 8
  %_50.sroa.6.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 3, i32 3
  store ptr %_5.i69, ptr %_50.sroa.6.0..sroa_idx, align 8
  %_50.sroa.7.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 3, i32 4
  store i64 %_6.i70, ptr %_50.sroa.7.0..sroa_idx, align 8
  %_50.sroa.8.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 3, i32 5
  store i8 %65, ptr %_50.sroa.8.0..sroa_idx, align 8
  %_50.sroa.9.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 3, i32 6
  store i8 %67, ptr %_50.sroa.9.0..sroa_idx, align 1
  %_50.sroa.10.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 3, i32 7
  store i8 %69, ptr %_50.sroa.10.0..sroa_idx, align 2
  %93 = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 4
  store ptr %_2.i74, ptr %93, align 8
  %_51.sroa.4.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 4, i32 1
  store ptr %_12.i75, ptr %_51.sroa.4.0..sroa_idx, align 8
  %_51.sroa.5.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 4, i32 2
  store ptr %_16.i81, ptr %_51.sroa.5.0..sroa_idx, align 8
  %_51.sroa.6.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 4, i32 3
  store ptr %_5.i86, ptr %_51.sroa.6.0..sroa_idx, align 8
  %_51.sroa.7.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 4, i32 4
  store i64 %_6.i87, ptr %_51.sroa.7.0..sroa_idx, align 8
  %_51.sroa.8.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 4, i32 5
  store i8 %75, ptr %_51.sroa.8.0..sroa_idx, align 8
  %_51.sroa.9.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 4, i32 6
  store i8 %77, ptr %_51.sroa.9.0..sroa_idx, align 1
  %_51.sroa.10.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 4, i32 7
  store i8 %79, ptr %_51.sroa.10.0..sroa_idx, align 2
  %94 = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 5
  store ptr %_2.i91, ptr %94, align 8
  %_52.sroa.4.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 5, i32 1
  store ptr %_12.i92, ptr %_52.sroa.4.0..sroa_idx, align 8
  %_52.sroa.5.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 5, i32 2
  store ptr %_16.i98, ptr %_52.sroa.5.0..sroa_idx, align 8
  %_52.sroa.6.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 5, i32 3
  store ptr %_5.i103, ptr %_52.sroa.6.0..sroa_idx, align 8
  %_52.sroa.7.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 5, i32 4
  store i64 %_6.i104, ptr %_52.sroa.7.0..sroa_idx, align 8
  %_52.sroa.8.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 5, i32 5
  store i8 %85, ptr %_52.sroa.8.0..sroa_idx, align 8
  %_52.sroa.9.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 5, i32 6
  store i8 %87, ptr %_52.sroa.9.0..sroa_idx, align 1
  %_52.sroa.10.0..sroa_idx = getelementptr inbounds [6 x %"solana_account_info::AccountInfo<'_>"], ptr %_46, i64 0, i64 5, i32 7
  store i8 %89, ptr %_52.sroa.10.0..sroa_idx, align 2
; call solana_program::program::invoke
  call void @_ZN14solana_program7program6invoke17h1429e3528cf88cd1E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_42, ptr noalias noundef nonnull readonly align 8 dereferenceable(80) %instruction, ptr noalias noundef nonnull readonly align 8 %_46, i64 noundef 6) #25
  %95 = load i64, ptr %_42, align 8, !range !222, !noundef !2
  %96 = icmp eq i64 %95, -9223372036854775782
  br i1 %96, label %bb50, label %bb49

bb50:                                             ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit107"
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_42)
; call core::ptr::drop_in_place<[solana_account_info::AccountInfo; 6]>
  call fastcc void @"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$6$u5d$$GT$17hc04de8ec0b5f33f8E"(ptr noalias noundef nonnull align 8 dereferenceable(288) %_46) #25
  call void @llvm.lifetime.end.p0(i64 288, ptr nonnull %_46)
  %_1.val.i = load i64, ptr %instruction, align 8, !alias.scope !5777, !noundef !2
  %97 = icmp eq i64 %_1.val.i, 0
  br i1 %97, label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h7342aa77271ec2efE.exit.i", label %bb2.i.i.i.i

bb2.i.i.i.i:                                      ; preds = %bb50
  %98 = getelementptr inbounds i8, ptr %instruction, i64 8
  %_1.val2.i = load ptr, ptr %98, align 8, !alias.scope !5777
  %99 = icmp ne ptr %_1.val2.i, null
  call void @llvm.assume(i1 %99)
  br label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h7342aa77271ec2efE.exit.i"

"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h7342aa77271ec2efE.exit.i": ; preds = %bb2.i.i.i.i, %bb50
  %100 = getelementptr inbounds i8, ptr %instruction, i64 24
  %.val.i = load i64, ptr %100, align 8, !alias.scope !5777, !noundef !2
  %101 = icmp eq i64 %.val.i, 0
  br i1 %101, label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h877e270bb2588328E.exit", label %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i"

"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i": ; preds = %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h7342aa77271ec2efE.exit.i"
  %102 = getelementptr inbounds i8, ptr %instruction, i64 32
  %.val1.i = load ptr, ptr %102, align 8, !alias.scope !5777
  %103 = icmp ne ptr %.val1.i, null
  call void @llvm.assume(i1 %103)
  br label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h877e270bb2588328E.exit"

"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h877e270bb2588328E.exit": ; preds = %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h7342aa77271ec2efE.exit.i", %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i"
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %instruction)
  br label %bb23

bb49:                                             ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17hf27d0aab30a408b2E.exit107"
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_111)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_111, ptr noundef nonnull align 8 dereferenceable(24) %_42, i64 24, i1 false)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_42)
; call <anchor_lang::error::Error as core::convert::From<solana_program_error::ProgramError>>::from
  %104 = call { i64, ptr } @"_ZN107_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$solana_program_error..ProgramError$GT$$GT$4from17he548966f566ce008E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(24) %_111) #25
  %_112.0 = extractvalue { i64, ptr } %104, 0
  %_112.1 = extractvalue { i64, ptr } %104, 1
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_111)
; call core::ptr::drop_in_place<[solana_account_info::AccountInfo; 6]>
  call fastcc void @"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$6$u5d$$GT$17hc04de8ec0b5f33f8E"(ptr noalias noundef nonnull align 8 dereferenceable(288) %_46) #25
  call void @llvm.lifetime.end.p0(i64 288, ptr nonnull %_46)
  %_1.val.i108 = load i64, ptr %instruction, align 8, !alias.scope !5780, !noundef !2
  %105 = icmp eq i64 %_1.val.i108, 0
  br i1 %105, label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h7342aa77271ec2efE.exit.i111", label %bb2.i.i.i.i109

bb2.i.i.i.i109:                                   ; preds = %bb49
  %106 = getelementptr inbounds i8, ptr %instruction, i64 8
  %_1.val2.i110 = load ptr, ptr %106, align 8, !alias.scope !5780
  %107 = icmp ne ptr %_1.val2.i110, null
  call void @llvm.assume(i1 %107)
  br label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h7342aa77271ec2efE.exit.i111"

"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h7342aa77271ec2efE.exit.i111": ; preds = %bb2.i.i.i.i109, %bb49
  %108 = getelementptr inbounds i8, ptr %instruction, i64 24
  %.val.i112 = load i64, ptr %108, align 8, !alias.scope !5780, !noundef !2
  %109 = icmp eq i64 %.val.i112, 0
  br i1 %109, label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h877e270bb2588328E.exit115", label %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i113"

"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i113": ; preds = %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h7342aa77271ec2efE.exit.i111"
  %110 = getelementptr inbounds i8, ptr %instruction, i64 32
  %.val1.i114 = load ptr, ptr %110, align 8, !alias.scope !5780
  %111 = icmp ne ptr %.val1.i114, null
  call void @llvm.assume(i1 %111)
  br label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h877e270bb2588328E.exit115"

"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h877e270bb2588328E.exit115": ; preds = %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h7342aa77271ec2efE.exit.i111", %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i113"
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %instruction)
  br label %bb43

bb29:                                             ; preds = %bb23
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_70)
; call solana_account_info::AccountInfo::try_borrow_data
  call void @_ZN19solana_account_info11AccountInfo15try_borrow_data17hfaae3b3f86f51a0bE(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_70, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %associated_account) #25
  %112 = load i64, ptr %_70, align 8, !range !222, !noundef !2
  %113 = icmp eq i64 %112, -9223372036854775782
  %114 = getelementptr inbounds i8, ptr %_70, i64 8
  %_117.0 = load ptr, ptr %114, align 8
  %115 = getelementptr inbounds i8, ptr %_70, i64 16
  %_117.1 = load ptr, ptr %115, align 8
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_70)
  br i1 %113, label %bb55, label %bb54

bb24:                                             ; preds = %bb23
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_57)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_58)
; call pump_fees_candidate::FeeError::name
  call void @_ZN19pump_fees_candidate8FeeError4name17h05af46396e0a9befE(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_58, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_c494d62ab9e88ddf93a565513be3cd06) #25
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i116)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i118), !noalias !5783
  store i64 0, ptr %buf.i118, align 8, !noalias !5783
  %_9.sroa.4.0.buf.sroa_idx.i119 = getelementptr inbounds i8, ptr %buf.i118, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i119, align 8, !noalias !5783
  %_9.sroa.5.0.buf.sroa_idx.i120 = getelementptr inbounds i8, ptr %buf.i118, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i120, align 8, !noalias !5783
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i117), !noalias !5783
  %116 = getelementptr inbounds i8, ptr %formatter.i117, i64 52
  store i32 0, ptr %116, align 4, !noalias !5783
  %117 = getelementptr inbounds i8, ptr %formatter.i117, i64 48
  store i32 32, ptr %117, align 8, !noalias !5783
  %118 = getelementptr inbounds i8, ptr %formatter.i117, i64 56
  store i8 3, ptr %118, align 8, !noalias !5783
  store i64 0, ptr %formatter.i117, align 8, !noalias !5783
  %119 = getelementptr inbounds i8, ptr %formatter.i117, i64 16
  store i64 0, ptr %119, align 8, !noalias !5783
  %120 = getelementptr inbounds i8, ptr %formatter.i117, i64 32
  store ptr %buf.i118, ptr %120, align 8, !noalias !5783
  %121 = getelementptr inbounds i8, ptr %formatter.i117, i64 40
  store ptr @vtable.1, ptr %121, align 8, !noalias !5783
; call <pump_fees_candidate::FeeError as core::fmt::Display>::fmt
  %122 = call noundef zeroext i1 @"_ZN68_$LT$pump_fees_candidate..FeeError$u20$as$u20$core..fmt..Display$GT$3fmt17h61107ac132b6933dE"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_c494d62ab9e88ddf93a565513be3cd06, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i117) #25, !noalias !5787
  br i1 %122, label %bb3.i121, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hbfb4ebc83811e844E.exit"

bb3.i121:                                         ; preds = %bb24
; call core::result::unwrap_failed
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i116, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.2, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #26, !noalias !5783
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hbfb4ebc83811e844E.exit": ; preds = %bb24
  %123 = getelementptr inbounds i8, ptr %_57, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %123, ptr noundef nonnull align 8 dereferenceable(24) %buf.i118, i64 24, i1 false)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i117), !noalias !5783
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i118), !noalias !5783
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i116)
  %124 = getelementptr inbounds i8, ptr %_57, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %124, ptr noundef nonnull align 8 dereferenceable(24) %_58, i64 24, i1 false)
  %125 = getelementptr inbounds i8, ptr %_57, i64 152
  store i32 6029, ptr %125, align 8
  store i64 0, ptr %_57, align 8
  %_61.sroa.4.0._57.sroa_idx = getelementptr inbounds i8, ptr %_57, i64 8
  store ptr @alloc_a5bc4269938b4f19311b42ee946762e5, ptr %_61.sroa.4.0._57.sroa_idx, align 8
  %_61.sroa.4.sroa.4.0._61.sroa.4.0._57.sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_57, i64 16
  store i64 54, ptr %_61.sroa.4.sroa.4.0._61.sroa.4.0._57.sroa_idx.sroa_idx, align 8
  %_61.sroa.4.sroa.5.0._61.sroa.4.0._57.sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_57, i64 24
  store i32 299, ptr %_61.sroa.4.sroa.5.0._61.sroa.4.0._57.sroa_idx.sroa_idx, align 8
  %126 = getelementptr inbounds i8, ptr %_57, i64 80
  store i8 2, ptr %126, align 8
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_58)
; call <anchor_lang::error::Error as core::convert::From<anchor_lang::error::AnchorError>>::from
  %127 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h98c0c5a28b5a1c88E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_57) #25
  %_56.0 = extractvalue { i64, ptr } %127, 0
  %_56.1 = extractvalue { i64, ptr } %127, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_57)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %_65)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_65, ptr noundef nonnull align 1 dereferenceable(32) %_101, i64 32, i1 false)
  %128 = getelementptr inbounds i8, ptr %_65, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %128, ptr noundef nonnull align 1 dereferenceable(32) %token_program, i64 32, i1 false)
; call anchor_lang::error::Error::with_pubkeys
  %129 = call { i64, ptr } @_ZN11anchor_lang5error5Error12with_pubkeys17hda5126e2516455afE(i64 noundef %_56.0, ptr noundef %_56.1, ptr noalias nocapture noundef nonnull readonly align 1 dereferenceable(64) %_65) #25
  %_55.0 = extractvalue { i64, ptr } %129, 0
  %_55.1 = extractvalue { i64, ptr } %129, 1
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %_65)
  br label %bb43

bb55:                                             ; preds = %bb29
  call void @llvm.lifetime.start.p0(i64 176, ptr nonnull %account)
  call void @llvm.lifetime.start.p0(i64 176, ptr nonnull %_75)
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_77)
  %130 = icmp ne ptr %_117.0, null
  call void @llvm.assume(i1 %130)
  %_95.0 = load ptr, ptr %_117.0, align 8, !nonnull !2, !align !209, !noundef !2
  %131 = getelementptr inbounds i8, ptr %_117.0, i64 8
  %_95.1 = load i64, ptr %131, align 8, !noundef !2
  store ptr %_95.0, ptr %_77, align 8
  %132 = getelementptr inbounds i8, ptr %_77, i64 8
  store i64 %_95.1, ptr %132, align 8
; call <anchor_spl::token_interface::TokenAccount as anchor_lang::AccountDeserialize>::try_deserialize_unchecked
  call void @"_ZN93_$LT$anchor_spl..token_interface..TokenAccount$u20$as$u20$anchor_lang..AccountDeserialize$GT$25try_deserialize_unchecked17he456238c5029534fE"(ptr noalias nocapture noundef nonnull sret([176 x i8]) align 8 dereferenceable(176) %_75, ptr noalias noundef nonnull align 8 dereferenceable(16) %_77) #25
  %133 = getelementptr inbounds i8, ptr %_75, i64 136
  %134 = load i32, ptr %133, align 8, !range !223, !noundef !2
  %135 = icmp eq i32 %134, 2
  %_126.0 = load i64, ptr %_75, align 8
  %136 = getelementptr inbounds i8, ptr %_75, i64 8
  %_126.1 = load ptr, ptr %136, align 8
  br i1 %135, label %bb58, label %bb59

bb54:                                             ; preds = %bb29
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_122)
  store i64 %112, ptr %_122, align 8
  %residual1.sroa.2.0._122.sroa_idx = getelementptr inbounds i8, ptr %_122, i64 8
  store ptr %_117.0, ptr %residual1.sroa.2.0._122.sroa_idx, align 8
  %residual1.sroa.3.0._122.sroa_idx = getelementptr inbounds i8, ptr %_122, i64 16
  store ptr %_117.1, ptr %residual1.sroa.3.0._122.sroa_idx, align 8
; call <anchor_lang::error::Error as core::convert::From<solana_program_error::ProgramError>>::from
  %137 = call { i64, ptr } @"_ZN107_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$solana_program_error..ProgramError$GT$$GT$4from17he548966f566ce008E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(24) %_122) #25
  %_123.0 = extractvalue { i64, ptr } %137, 0
  %_123.1 = extractvalue { i64, ptr } %137, 1
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_122)
  br label %bb43

bb59:                                             ; preds = %bb55
  %_125.sroa.6.0._75.sroa_idx = getelementptr inbounds i8, ptr %_75, i64 16
  %val.sroa.3.0.account.sroa_idx = getelementptr inbounds i8, ptr %account, i64 16
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(120) %val.sroa.3.0.account.sroa_idx, ptr noundef nonnull align 8 dereferenceable(120) %_125.sroa.6.0._75.sroa_idx, i64 120, i1 false)
  %_125.sroa.8.0._75.sroa_idx = getelementptr inbounds i8, ptr %_75, i64 140
  %val.sroa.5.0.account.sroa_idx = getelementptr inbounds i8, ptr %account, i64 140
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(36) %val.sroa.5.0.account.sroa_idx, ptr noundef nonnull align 4 dereferenceable(36) %_125.sroa.8.0._75.sroa_idx, i64 36, i1 false)
  call void @llvm.lifetime.end.p0(i64 176, ptr nonnull %_75)
  store i64 %_126.0, ptr %account, align 8
  %val.sroa.2.0.account.sroa_idx = getelementptr inbounds i8, ptr %account, i64 8
  store ptr %_126.1, ptr %val.sroa.2.0.account.sroa_idx, align 8
  %val.sroa.4.0.account.sroa_idx = getelementptr inbounds i8, ptr %account, i64 136
  store i32 %134, ptr %val.sroa.4.0.account.sroa_idx, align 8
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_77)
  %138 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %account, ptr noundef nonnull dereferenceable(32) %mint, i64 32)
  %.not14 = icmp eq i32 %138, 0
  br i1 %.not14, label %bb36, label %bb31

bb58:                                             ; preds = %bb55
  call void @llvm.lifetime.end.p0(i64 176, ptr nonnull %_75)
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_77)
  br label %bb38

bb36:                                             ; preds = %bb59
  call void @llvm.lifetime.end.p0(i64 176, ptr nonnull %account)
  %139 = icmp ne ptr %_117.1, null
  call void @llvm.assume(i1 %139)
  %borrow.i.i.i = load i64, ptr %_117.1, align 8, !noundef !2
  %val.i.i.i = add i64 %borrow.i.i.i, -1
  store i64 %val.i.i.i, ptr %_117.1, align 8
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %expected)
  br label %bb44

bb31:                                             ; preds = %bb59
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_83)
  %140 = getelementptr inbounds i8, ptr %_83, i64 32
; call pump_fees_candidate::FeeError::name
  call void @_ZN19pump_fees_candidate8FeeError4name17h05af46396e0a9befE(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %140, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_0e3505805f4905816c1bd644811a7869) #25
  %141 = getelementptr inbounds i8, ptr %_83, i64 56
; call <T as alloc::string::ToString>::to_string
  call fastcc void @"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hbfb4ebc83811e844E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %141, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_0e3505805f4905816c1bd644811a7869) #25
  %142 = getelementptr inbounds i8, ptr %_83, i64 152
  store i32 6030, ptr %142, align 8
  store i64 0, ptr %_83, align 8
  %_87.sroa.4.0._83.sroa_idx = getelementptr inbounds i8, ptr %_83, i64 8
  store ptr @alloc_a5bc4269938b4f19311b42ee946762e5, ptr %_87.sroa.4.0._83.sroa_idx, align 8
  %_87.sroa.4.sroa.4.0._87.sroa.4.0._83.sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_83, i64 16
  store i64 54, ptr %_87.sroa.4.sroa.4.0._87.sroa.4.0._83.sroa_idx.sroa_idx, align 8
  %_87.sroa.4.sroa.5.0._87.sroa.4.0._83.sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_83, i64 24
  store i32 306, ptr %_87.sroa.4.sroa.5.0._87.sroa.4.0._83.sroa_idx.sroa_idx, align 8
  %143 = getelementptr inbounds i8, ptr %_83, i64 80
  store i8 2, ptr %143, align 8
; call <anchor_lang::error::Error as core::convert::From<anchor_lang::error::AnchorError>>::from
  %144 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h98c0c5a28b5a1c88E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_83) #25
  %_82.0 = extractvalue { i64, ptr } %144, 0
  %_82.1 = extractvalue { i64, ptr } %144, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_83)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %_91)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_91, ptr noundef nonnull align 8 dereferenceable(32) %account, i64 32, i1 false)
  %145 = getelementptr inbounds i8, ptr %_91, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %145, ptr noundef nonnull align 1 dereferenceable(32) %mint, i64 32, i1 false)
; call anchor_lang::error::Error::with_pubkeys
  %146 = call { i64, ptr } @_ZN11anchor_lang5error5Error12with_pubkeys17hda5126e2516455afE(i64 noundef %_82.0, ptr noundef %_82.1, ptr noalias nocapture noundef nonnull readonly align 1 dereferenceable(64) %_91) #25
  %_81.0 = extractvalue { i64, ptr } %146, 0
  %_81.1 = extractvalue { i64, ptr } %146, 1
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %_91)
  br label %bb38

bb44:                                             ; preds = %bb43, %bb36
  %_0.sroa.9.0 = phi ptr [ %_0.sroa.9.3, %bb43 ], [ undef, %bb36 ]
  %_0.sroa.0.0 = phi i64 [ %_0.sroa.0.3, %bb43 ], [ 2, %bb36 ]
  %147 = insertvalue { i64, ptr } poison, i64 %_0.sroa.0.0, 0
  %148 = insertvalue { i64, ptr } %147, ptr %_0.sroa.9.0, 1
  ret { i64, ptr } %148

bb38:                                             ; preds = %bb58, %bb31
  %_0.sroa.9.1 = phi ptr [ %_126.1, %bb58 ], [ %_81.1, %bb31 ]
  %_0.sroa.0.1 = phi i64 [ %_126.0, %bb58 ], [ %_81.0, %bb31 ]
  call void @llvm.lifetime.end.p0(i64 176, ptr nonnull %account)
  %149 = icmp ne ptr %_117.1, null
  call void @llvm.assume(i1 %149)
  %borrow.i.i.i122 = load i64, ptr %_117.1, align 8, !noundef !2
  %val.i.i.i123 = add i64 %borrow.i.i.i122, -1
  store i64 %val.i.i.i123, ptr %_117.1, align 8
  br label %bb43

bb43:                                             ; preds = %bb38, %bb54, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h3f8720cb5c1d2f09E.exit22", %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h877e270bb2588328E.exit115", %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h3f8720cb5c1d2f09E.exit", %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hbfb4ebc83811e844E.exit"
  %_0.sroa.9.3 = phi ptr [ %_15.1, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h3f8720cb5c1d2f09E.exit" ], [ %_55.1, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hbfb4ebc83811e844E.exit" ], [ %_112.1, %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h877e270bb2588328E.exit115" ], [ %_28.1, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h3f8720cb5c1d2f09E.exit22" ], [ %_0.sroa.9.1, %bb38 ], [ %_123.1, %bb54 ]
  %_0.sroa.0.3 = phi i64 [ %_15.0, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h3f8720cb5c1d2f09E.exit" ], [ %_55.0, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hbfb4ebc83811e844E.exit" ], [ %_112.0, %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h877e270bb2588328E.exit115" ], [ %_28.0, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h3f8720cb5c1d2f09E.exit22" ], [ %_0.sroa.0.1, %bb38 ], [ %_123.0, %bb54 ]
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %expected)
  br label %bb44
}
